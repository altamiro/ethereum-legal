<template>
  <v-app>
    <v-content>
      <v-container fluid fill-height>
        <v-layout align-center justify-center>
          <v-flex xs12 sm8 md4>
            <v-card class="elevation-12">
              <v-toolbar dark color="error">
                <v-toolbar-title>ERRO 401</v-toolbar-title>
              </v-toolbar>
              <v-card-text>
                {{ $t('erro.401') }}
              </v-card-text>
            </v-card>
          </v-flex>
        </v-layout>
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
export default {
  name: '401',
}
</script>