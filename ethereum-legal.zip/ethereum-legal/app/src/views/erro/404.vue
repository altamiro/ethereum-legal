<template>
  <v-app>
    <v-content>
      <v-container fluid fill-height>
        <v-layout align-center justify-center>
          <v-flex xs12 sm8 md4>
            <v-card class="elevation-12">
              <v-toolbar dark color="error">
                <v-toolbar-title>ERRO 404</v-toolbar-title>
              </v-toolbar>
              <v-card-text>
                {{ $t('erro.404') }}
              </v-card-text>
            </v-card>
          </v-flex>
        </v-layout>
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
export default {
  name: '404',
}
</script>