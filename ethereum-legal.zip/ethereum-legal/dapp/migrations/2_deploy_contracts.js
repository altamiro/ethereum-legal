let NotaLegal = artifacts.require("./NotaLegal.sol");

module.exports = function(deployer) {
  deployer.deploy(NotaLegal);
};
